from math import sqrt
from flask import Flask, send_from_directory, jsonify, request, render_template
import os
import cv2
import numpy as np
from PIL import Image
import networkx as nx
import math
from skimage.measure import approximate_polygon
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from PIL import Image
from collections import deque
import heapq
import requests
import json


app = Flask(__name__)

window_size = 33
error = 10
directions_distances=[]

# 현재 실행 중인 스크립트 파일의 경로 얻기
script_dir = os.path.dirname(__file__)

# 작업 디렉토리를 스크립트 파일이 있는 폴더로 변경
os.chdir(script_dir)

# HTML 페이지를 제공하는 라우트
@app.route('/map_touch.html')
def home():
    return render_template('map_touch.html')

# 사진을 찍어서 serve_image()에 올리는 라우트
@app.route('/capture_image', methods=['GET'])
def capture_image():
    filename = 'team_map.png'
    filepath = os.path.join('static', 'img', filename)
    capture_and_save_image(filepath)
    return jsonify({'status': 'success', 'image_path': filepath})

@app.route('/team_map.png')
def serve_image():
    return send_from_directory('static/img/', 'team_map.png')

# 좌표를 받아 처리하는 라우트
@app.route('/coordinates', methods=['POST'])
def handle_coordinates():
    data = request.get_json()
    x = data.get('x')
    y = data.get('y')
    print(f"Received coordinates: x={x}, y={y}")
    
    # 여기서 좌표에 따라 필요한 처리를 수행할 수 있습니다.
    capture_and_save_image('static/img/team_map.png')

    print(f"새로운 작업 디렉토리: {os.getcwd()}")





    #path_process = find_direction_and_adjust_angle('static/img/team_map.png')







    find_and_draw_path('static/img/team_map.png', (231,380), (int(x),int(y)))
    #find_and_draw_path('static/img/team_map.png', (path_process[0][0],path_process[0][1]), (x,y))
    return jsonify({"status": "success", "x": x, "y": y})

def capture_and_save_image(filepath):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("카메라를 열 수 없습니다.")
        return
    else:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    ret, img = cap.read()
    if ret:
        cv2.imwrite(filepath, img)
        print(f"{filepath}으로 사진이 저장되었습니다.")
    else:
        print("사진을 찍는 데 실패했습니다.")
    cap.release()

def calculate_angle_with_horizontal(cx, cy, fx, fy):
    """
    수평선과 (cx, cy)에서 (fx, fy)로 이어지는 선 사이의 각도를 계산합니다.
    """
    dx = fx - cx
    dy = fy - cy
    angle_radians = math.atan2(dy, dx)
    angle_degrees = math.degrees(angle_radians)
    return angle_degrees

def calculate_angle_with_horizontal(cX, cY, farX, farY):
    # 여기에 각도 계산 로직을 구현합니다.
    # 예시로, 단순히 수평선과의 각도를 계산하는 방법을 제공합니다.
    delta_x = farX - cX
    delta_y = farY - cY
    if delta_x == 0:  # 0으로 나누는 오류 방지
        return 0
    angle = np.arctan(delta_y / delta_x)
    angle = np.degrees(angle)
    return angle if delta_x > 0 else angle + 180

def find_direction_and_adjust_angle(filepath):
    img = cv2.imread(filepath)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # 파란색의 HSV 범위 정의
    lower_blue = np.array([110, 50, 50])
    upper_blue = np.array([130, 255, 255])

    # 파란색 영역 추출
    mask = cv2.inRange(hsv, lower_blue, upper_blue)

    # 컨투어 찾기
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    path_process = []

    for contour in contours:
        if cv2.contourArea(contour) < 20:  # 너무 작은 객체는 무시
            continue

        # 객체의 중심점 계산
        M = cv2.moments(contour)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
        else:
            continue  # 중심점을 구할 수 없는 경우는 무시

        # 가장 먼 점 찾기
        extLeft = tuple(contour[contour[:, :, 0].argmin()][0])
        extRight = tuple(contour[contour[:, :, 0].argmax()][0])
        extTop = tuple(contour[contour[:, :, 1].argmin()][0])
        extBot = tuple(contour[contour[:, :, 1].argmax()][0])

        distances = [((extLeft[0]-cX)**2 + (extLeft[1]-cY)**2, extLeft),
                     ((extRight[0]-cX)**2 + (extRight[1]-cY)**2, extRight),
                     ((extTop[0]-cX)**2 + (extTop[1]-cY)**2, extTop),
                     ((extBot[0]-cX)**2 + (extBot[1]-cY)**2, extBot)]

        farthest_point = max(distances, key=lambda x: x[0])[1]

        # 중심점과 가장 먼 점 사이의 각도 계산
        try:
            angle = calculate_angle_with_horizontal(cX, cY, farthest_point[0], farthest_point[1])
        except:
            angle = 0  # 계산할 수 없는 경우 0도로 설정

        # 각도 조정
        adjustment_angle = -angle

        # 결과 저장
        path_process.append((cX, cY, adjustment_angle))

    blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
    img[(blue_mask != 0)] = [255, 255, 255]

    # 이미지 저장
    cv2.imwrite('/content/map_delete_blue.png', img)

def calculate_angle_and_distance(from_point, to_point):
    """두 점 사이의 각도(도)와 거리를 계산합니다."""
    delta_x = to_point[0] - from_point[0]
    delta_y = to_point[1] - from_point[1]
    angle = math.atan2(delta_y, delta_x) * (180 / math.pi)  # 라디안을 도로 변환
    distance = math.sqrt(delta_x**2 + delta_y**2)
    return angle, distance

@app.route('/provide_list', methods=['GET'])
def provide_list():
    global directions_distances
    data =  directions_distances# 예시 이차원 리스트
    for_json_data=[list(item) for item in data]
    directions_distances=[]
    return jsonify(for_json_data)  # 이차원 리스트를 JSON 형태로 반환

'''
@app.route('/get_command', methods=['GET'])
def get_command():
    global directions_distances 
    command = directions_distances
    #directions_distances = None  # 명령어를 전송한 후에는 초기화
    if command:
        return jsonify({"data": command}), 200
    else:
        return jsonify({'error': 'No command'}), 404
'''

def point_line_distance(point, start, end):
    if start == end:
        return sqrt((point[0] - start[0])**2 + (point[1] - start[1])**2)
    else:
        num = abs((end[1] - start[1])*point[0] - (end[0] - start[0])*point[1] + end[0]*start[1] - end[1]*start[0])
        den = sqrt((end[1] - start[1])**2 + (end[0] - start[0])**2)
        return num / den

def ramer_douglas_peucker(points, epsilon):
    dmax = 0.0
    index = 0
    for i in range(1, len(points) - 1):
        d = point_line_distance(points[i], points[0], points[-1])
        if d > dmax:
            index = i
            dmax = d
    if dmax >= epsilon:
        rec_results1 = ramer_douglas_peucker(points[:index+1], epsilon)
        rec_results2 = ramer_douglas_peucker(points[index:], epsilon)
        
        return rec_results1[:-1] + rec_results2
    else:
        return [points[0], points[-1]]

# 명령을 출력하는 함수
def print_commands(commands):
    for command in commands:
        if command[0] == 'f':
            print(f"직진, 거리: {command[1]}")
        else:
            direction = "오른쪽" if command[0] == 'r' else "왼쪽"
            print(f"{direction} 회전, 거리: {command[1]}")  # 회전인 경우 거리는 항상 0

def preprocess_image(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY_INV)
    return binary

def find_shortest_path(img, start, end):
    height, width = img.shape
    queue = deque([(start, [])])
    visited = set()

    while queue:
        curr_pos, path = queue.popleft()
        if curr_pos == end:
            return path + [curr_pos]

        if curr_pos in visited:
            continue

        visited.add(curr_pos)

        x, y = curr_pos
        neighbors = [(x-1, y), (x+1, y), (x, y-1), (x, y+1)]

        for nx, ny in neighbors:
            if 0 <= nx < width and 0 <= ny < height and img[ny, nx] == 0:
                new_path = path + [(nx, ny)]
                queue.append(((nx, ny), new_path))

    return []

def calculate_direction_and_distance(points):
    directions_distances = []  # 방향과 거리 정보를 저장할 리스트

    # 두 좌표 간의 거리를 계산하는 함수
    def distance(A, B):
        return math.sqrt((B[0] - A[0])**2 + (B[1] - A[1])**2)

    # 벡터 외적을 계산하는 함수
    def cross_product(v1, v2):
        return v1[0] * v2[1] - v1[1] * v2[0]
    '''
    # 시작점에서 첫 번째 지점까지의 거리와 방향('f') 추가
    if len(points) > 1:
        directions_distances.append(('f', distance(points[0], points[1])))
    '''

    for i in range(0, len(points) - 2):
        A, B, C = points[i], points[i + 1], points[i + 2]

        AB = (B[0] - A[0], B[1] - A[1])
        BC = (C[0] - B[0], C[1] - B[1])

        cp = cross_product(AB, BC)
        dist = int(distance(A, B))  # B에서 C까지의 거리 계산

        # 외적의 결과에 따라 방향 결정 및 거리 추가
        if cp > 0:
            directions_distances.append(('r', dist))  # 양의 외적은 ('r') 방향과 거리
        elif cp < 0:
            directions_distances.append(('l', dist))  # 음의 외적은 ('l') 방향과 거리
        else:
            directions_distances.append(('s', dist))  # 0의 외적은 직진('s') 방향과 거리

    # 마지막 세그먼트의 방향은 계산하지 않으므로, 마지막 지점까지의 거리만 추가
    if len(points) > 2 and distance(points[-2], points[-1])>20:
        directions_distances.append(('f', int(distance(points[-2], points[-1]))))

    return directions_distances

def find_and_draw_path(filepath, start, end):
    global directions_distances
    img = cv2.imread(filepath)
    processed = preprocess_image(img)

    shortest_path = find_shortest_path(processed, start, end)

    if not shortest_path:
        print("No path found between the start and end points.")
        return

    print(f"Shortest path: {shortest_path}")

    simplified_points = ramer_douglas_peucker(shortest_path, 20)

    print(f"simplified_points: {simplified_points}")

    # 방향과 거리 계산 및 출력
    directions_distances = calculate_direction_and_distance(simplified_points)
    print(directions_distances)

    '''
    # 경로 시각화
    for pos in shortest_path:
        x, y = pos
        cv2.circle(img, (x, y), 3, (0, 255, 0), -1)

    plt.figure(figsize=(8, 8))
    plt.imshow(img)
    plt.xlabel('X')
    plt.ylabel('Y')
    '''
        

if __name__ == '__main__':
    app.run(debug=True, host='192.168.137.1', port=4080)
    #host를 ipv4 address로 바꿀것
