from flask import Flask, jsonify
from pynput.keyboard import Listener, Key
import time

app = Flask(__name__)

# 전역 변수로 최근 키 입력과 키가 눌렸는지 여부를 저장합니다.
recent_key = None
key_pressed = False
last_key = None  # 마지막으로 눌린 키를 저장하는 변수

def on_press(key):
    global recent_key, key_pressed, last_key
    if not key_pressed or (key_pressed and last_key != key):  # 키가 이미 눌려있지 않거나, 마지막으로 눌린 키와 다른 경우에만 처리
        key_pressed = True
        last_key = key  # 마지막으로 눌린 키를 업데이트
        try:
            print(f"Alphanumeric key {key.char} pressed")
            recent_key = key.char
        except AttributeError:
            print(f"Special key {key} pressed")
            if key == Key.space:
                recent_key = ' '
        time.sleep(0.1)

def on_release(key):
    global key_pressed
    key_pressed = False  # 키가 떼어졌으므로 상태를 업데이트

# 키보드 리스너 시작
listener = Listener(on_press=on_press, on_release=on_release)
listener.start()

@app.route('/get_command', methods=['GET'])
def get_command():
    global recent_key
    command = recent_key
    recent_key = None  # 명령어를 전송한 후에는 초기화
    if command:
        return jsonify({'command': command}), 
    else:
        return jsonify({'error': 'No command'}), 404

if __name__ == '__main__':
    app.run(host='192.168.137.1', port=4080, debug=True)