from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/provide_list', methods=['GET'])
def provide_list():
    data = [['l', 2], ['r', 4]]  # 예시 이차원 리스트
    return jsonify(data)  # 이차원 리스트를 JSON 형태로 반환

if __name__ == '__main__':
    app.run(debug=True, host='192.168.137.1', port=4080)
